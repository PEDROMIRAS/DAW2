// Seleccionamos el contenedor donde se mostrará la imagen
function mostrarImg() {
    img.src = "./assets/img/fotoCampoLopez4.jpg";
    img.style.width = "800px";
    contenerdor2.appendChild(img);
}