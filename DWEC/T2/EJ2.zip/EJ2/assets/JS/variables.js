// Variables y datos
const nombre = "Pedro Miras Pérez-Castejón";
const edad = 25;
const direccion = "Calle Falsa 123";
const telefono = "123456789";
const profesion = "Desarrollador Web";
const datos = [nombre, edad, direccion, telefono, profesion];

// Elementos del DOM
const contenerdor1 = document.getElementById("o1");
const contenerdor2 = document.getElementById("o2");
const btnPresentacion = document.getElementById("btnPresent");
const btnImg = document.getElementById("btnImg");
const btnGithub = document.getElementById("btnGitHub");
const img = document.createElement("img");