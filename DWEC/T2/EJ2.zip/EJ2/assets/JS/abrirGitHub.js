// Abre el repositorio de GitHub en una nueva pestaña
function abrirGitHub() {
    window.open("https://github.com/PEDROMIRAS", "_blank");
}