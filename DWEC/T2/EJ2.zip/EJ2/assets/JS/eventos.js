//Eventos de los botones del DOM
btnPresentacion.addEventListener("click", mostrarDatos);
btnImg.addEventListener("click", mostrarImg);
btnGithub.addEventListener("click", abrirGitHub);