<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        for ($i=1; $i <= 100; $i++) { 
            echo $i.",";
        }
        ?>
    <br>
    <?php
        $a = 10;
        while ($a >= 0) {
            if ($a!=0) {
                echo $a."-";
            }else{
                echo $a;
            }
            $a--;
        }
    ?>
</body>
</html>